<div class="alert alert-{{ $type }} alert-dismissible" role="alert">
    <p class="mb-0">
        {{ $slot }}
    </p>
</div>
